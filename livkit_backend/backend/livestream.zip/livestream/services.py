from django.utils.timezone import now
from payments.models import MinuteWallet, StreamEarning
from .models import WatchSession, Stream

PLATFORM_CUT = 0.30  # 30%

def start_watch_session(user, stream):
    return WatchSession.objects.create(user=user, stream=stream)


def update_watch_time(session: WatchSession):
    elapsed = (now() - session.last_seen).seconds
    session.seconds_watched += elapsed
    session.last_seen = now()
    session.save(update_fields=["seconds_watched", "last_seen"])


def deduct_viewer_minutes(user, seconds):
    wallet, _ = MinuteWallet.objects.get_or_create(user=user)
    if not wallet.can_watch(seconds):
        return False
    wallet.deduct(seconds)
    return True


def finalize_stream_earnings(stream: Stream):
    total_minutes = 0

    for session in stream.watchers.all():
        total_minutes += session.seconds_watched / 60  # convert to minutes

    earning = StreamEarning.objects.create(
        streamer=stream.host,
        stream_id=str(stream.id),
        minutes_watched=total_minutes,
        platform_cut=PLATFORM_CUT,
        payout_amount=total_minutes * (1 - PLATFORM_CUT)
    )

    return earning
