from celery import shared_task
from django.utils.timezone import now
from .models import Stream

@shared_task(bind=True, autoretry_for=(Exception,), retry_backoff=5, retry_kwargs={"max_retries": 5})
def auto_start_stream(stream_id):
    try:
        stream = Stream.objects.get(id=stream_id)
    except Stream.DoesNotExist:
        return "Stream not found"

    if stream.status != "scheduled":
        return "Stream already started or ended"

    stream.status = "live"
    stream.started_at = now()
    stream.save(update_fields=["status", "started_at"])

    return f"Stream {stream.id} is now live"
