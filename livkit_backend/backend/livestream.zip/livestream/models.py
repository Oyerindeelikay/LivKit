from django.db import models
from django.conf import settings

from django.utils.timezone import now

User = settings.AUTH_USER_MODEL

class Stream(models.Model):
    STATUS_CHOICES = (
        ("scheduled", "Scheduled"),
        ("live", "Live"),
        ("ended", "Ended"),
    )

    host = models.ForeignKey(User, on_delete=models.CASCADE, related_name="hosted_streams")
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    channel_name = models.CharField(max_length=255, unique=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="scheduled")

    scheduled_start = models.DateTimeField(null=True, blank=True)
    started_at = models.DateTimeField(null=True, blank=True)
    ended_at = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} - {self.host}"


class WatchSession(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="watch_sessions")
    stream = models.ForeignKey(Stream, on_delete=models.CASCADE, related_name="watchers")

    started_at = models.DateTimeField(auto_now_add=True)
    last_seen = models.DateTimeField(auto_now=True)
    seconds_watched = models.BigIntegerField(default=0)
    active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.user} watching {self.stream}"


class Gift(models.Model):
    name = models.CharField(max_length=100)
    coin_cost = models.IntegerField()
    image_url = models.URLField(blank=True, null=True)

    def __str__(self):
        return self.name


class GiftTransaction(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name="sent_gifts")
    receiver = models.ForeignKey(User, on_delete=models.CASCADE, related_name="received_gifts")
    stream = models.ForeignKey(Stream, on_delete=models.CASCADE, related_name="gifts")
    gift = models.ForeignKey(Gift, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)



class StreamViewerSession(models.Model):
    """
    A real-time viewer session tied to a WebSocket connection.
    This is the single source of truth for:
    - Who is watching
    - Exactly how long they've watched
    - Exactly how much time they have left (in seconds)
    """

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="stream_viewer_sessions"
    )

    stream = models.ForeignKey(
        "Stream",
        on_delete=models.CASCADE,
        related_name="viewer_sessions"
    )

    joined_at = models.DateTimeField(default=now)

    last_heartbeat = models.DateTimeField(default=now)

    # >>>>> THIS IS THE CRITICAL CHANGE <<<<<
    remaining_seconds = models.BigIntegerField()

    is_active = models.BooleanField(default=True)

    websocket_channel_name = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        db_index=True
    )

    disconnected_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        indexes = [
            models.Index(fields=["stream", "is_active"]),
            models.Index(fields=["user", "is_active"]),
        ]

    def __str__(self):
        return (
            f"{self.user} watching {self.stream} "
            f"({self.remaining_seconds}s left, "
            f"{'active' if self.is_active else 'ended'})"
        )
