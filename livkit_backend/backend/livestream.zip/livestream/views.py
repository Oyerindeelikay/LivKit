from django.utils.timezone import now
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status

from .models import Stream, WatchSession, Gift, GiftTransaction
from .services import (
    start_watch_session,
    update_watch_time,
    deduct_viewer_minutes,
    finalize_stream_earnings,
)

from payments.models import CoinWallet, CoinLedger, MinuteWallet
from .agora import issue_agora_token

from .tasks import auto_start_stream
from django.utils.dateparse import parse_datetime

# ==============================
# CREATE STREAM (SCHEDULE OR LIVE)
# ==============================

class CreateStreamView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        title = request.data.get("title")
        description = request.data.get("description","")
        scheduled_start = request.data.get("scheduled_start")  # ISO format

        if not title:
        	return Response({"detail": "Title is required"}, status=400)

        channel_name = f"stream_{request.user.id}_{int(now().timestamp())}"


        stream = Stream.objects.create(
        	host=request.user,
        	title=title,
        	description=description,
        	channel_name=channel_name,
        	scheduled_start=parse_datetime(scheduled_start) if scheduled_start else None,
        	status="scheduled" if scheduled_start else "live",
        	started_at=now() if not scheduled_start else None,
        )

        if scheduled_start:
        	auto_start_stream.apply_async(
        		args=[stream.id],
        		eta=parse_datetime(scheduled_start)
        	)

        return Response({
            "id": stream.id,
            "title": stream.title,
            "channel_name": stream.channel_name,
		    "status": stream.status,
		    "scheduled_start": stream.scheduled_start,
		    "watch_link": f"/streams/{stream.id}/join/"
		})


# ==============================
# START STREAM (GO LIVE)
# ==============================

class StartStreamView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, stream_id):
        try:
            stream = Stream.objects.get(id=stream_id, host=request.user)
        except Stream.DoesNotExist:
            return Response({"detail": "Stream not found or not yours"}, status=404)

        if stream.status == "live":
            return Response({"detail": "Stream already live"}, status=400)

        stream.status = "live"
        stream.started_at = now()
        stream.save(update_fields=["status", "started_at"])

        # Issue Agora token for streamer
        token = issue_agora_token(
            user=request.user,
            channel=stream.channel_name,
            ttl=3600,   # 1 hour
            role="publisher"
        )

        return Response({
            "detail": "Stream started",
            "agora_token": token,
            "channel": stream.channel_name
        })


# ==============================
# JOIN STREAM (VIEWER)
# ==============================

class JoinStreamView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, stream_id):
        try:
            stream = Stream.objects.get(id=stream_id, status="live")
        except Stream.DoesNotExist:
            return Response({"detail": "Stream is not live"}, status=404)

        # Ensure viewer has a MinuteWallet
        wallet, _ = MinuteWallet.objects.get_or_create(user=request.user)

        if wallet.seconds_balance <= 0:
            return Response(
                {"detail": "No watch minutes left. Please purchase more."},
                status=402
            )

        # Create watch session
        session = start_watch_session(request.user, stream)

        # Issue Agora token for viewer
        token = issue_agora_token(
            user=request.user,
            channel=stream.channel_name,
            ttl=300,   # 5 minutes
            role="subscriber"
        )

        return Response({
            "detail": "Joined stream",
            "session_id": session.id,
            "agora_token": token,
            "channel": stream.channel_name
        })



# ==============================
# END STREAM (FINALIZE EARNINGS)
# ==============================

class EndStreamView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, stream_id):
        try:
            stream = Stream.objects.get(id=stream_id, host=request.user)
        except Stream.DoesNotExist:
            return Response({"detail": "Stream not found or not yours"}, status=404)

        if stream.status == "ended":
            return Response({"detail": "Stream already ended"}, status=400)

        # Mark stream ended
        stream.status = "ended"
        stream.ended_at = now()
        stream.save(update_fields=["status", "ended_at"])

        # Deactivate all watch sessions
        WatchSession.objects.filter(stream=stream, active=True).update(active=False)

        # Finalize earnings
        earnings = finalize_stream_earnings(stream)

        return Response({
            "detail": "Stream ended",
            "minutes_watched": earnings.minutes_watched,
            "payout_estimate": earnings.payout_amount
        })


# ==============================
# SEND GIFT
# ==============================

from django.db import transaction
from django.db.models import F

class SendGiftView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, stream_id):
        gift_id = request.data.get("gift_id")

        try:
            stream = Stream.objects.get(id=stream_id, status="live")
        except Stream.DoesNotExist:
            return Response({"detail": "Stream not live"}, status=404)

        try:
            gift = Gift.objects.get(id=gift_id)
        except Gift.DoesNotExist:
            return Response({"detail": "Invalid gift"}, status=400)

        wallet, _ = CoinWallet.objects.get_or_create(user=request.user)

        # HARD GUARD (before transaction)
        if wallet.balance < gift.coin_cost:
            return Response({"detail": "Not enough coins"}, status=402)

        with transaction.atomic():
            # Lock wallet row to prevent race conditions
            wallet = (
                CoinWallet.objects
                .select_for_update()
                .get(user=request.user)
            )

            if wallet.balance < gift.coin_cost:
                return Response({"detail": "Not enough coins"}, status=402)

            # 1️⃣ Deduct coins
            wallet.balance = F("balance") - gift.coin_cost
            wallet.save(update_fields=["balance"])

            # 2️⃣ Ledger entry
            CoinLedger.objects.create(
                user=request.user,
                action="gift",
                amount=gift.coin_cost,
            )

            # 3️⃣ Gift transaction
            GiftTransaction.objects.create(
                sender=request.user,
                receiver=stream.host,
                stream=stream,
                gift=gift,
            )

            # 4️⃣ Accumulate streamer earnings
            StreamEarning.objects.update_or_create(
                streamer=stream.host,
                stream_id=str(stream.id),
                defaults={
                    "gifts_received": F("gifts_received") + gift.coin_cost
                },
            )

        return Response({
            "detail": f"Sent {gift.name} to {stream.host.username}"
        })
