from django.urls import path
from .consumers import StreamViewerConsumer

websocket_urlpatterns = [
    path("ws/livestream/<uuid:stream_id>/", StreamViewerConsumer.as_asgi()),
]
