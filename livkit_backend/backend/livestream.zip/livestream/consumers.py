import asyncio
import json
from datetime import timedelta

from channels.generic.websocket import AsyncWebsocketConsumer
from django.utils.timezone import now
from django.contrib.auth import get_user_model
from asgiref.sync import sync_to_async

from .models import Stream, StreamViewerSession
from payments.models import UserMinuteBalance  # Adjust if your model name is different

from payments.models import MinuteWallet, MinuteLedger


User = get_user_model()



class StreamViewerConsumer(AsyncWebsocketConsumer):

    @sync_to_async
    def reserve_minutes_for_session(self, user, seconds):
        wallet, _ = MinuteWallet.objects.get_or_create(user=user)
        wallet.reserve_for_stream(seconds)


    async def connect(self):
        self.user = self.scope["user"]

        # HARD STOP if not authenticated
        if not self.user or not self.user.is_authenticated:
            await self.close()
            return

        # Get stream ID from URL
        self.stream_id = self.scope["url_route"]["kwargs"]["stream_id"]

        # Load stream safely
        self.stream = await self.get_stream(self.stream_id)
        if not self.stream:
            await self.close()
            return

        # Reject if stream is not live
        if not self.stream.is_live:
            await self.close()
            return

        # Get user's available minutes
        available_seconds = await self.get_user_seconds(self.user)

        reserve_seconds = min(available_seconds, 300)




        if available_seconds <= 0:
            await self.close()
            return

        # Reserve all available time for this session
        await self.reserve_minutes_for_session(self.user, available_seconds)


        if remaining_minutes <= 0:
            await self.close()
            return

        # Create real viewer session in DB
        self.viewer_session = await self.create_viewer_session(
            user=self.user,
            stream=self.stream,
            remaining_minutes=remaining_minutes,
            channel_name=self.channel_name,
        )

        # Accept connection
        await self.accept()

        # Start heartbeat loop
        self.keep_running = True
        self.heartbeat_task = asyncio.create_task(self.heartbeat_loop())



    async def disconnect(self, close_code):
        """
        Fired when:
        - user leaves
        - app crashes
        - internet drops
        - server closes connection
        """
        self.keep_running = False

        if hasattr(self, "viewer_session"):
            await self.end_viewer_session(self.viewer_session)

    async def receive(self, text_data=None, bytes_data=None):
        """
        You don't actually need client messages yet.
        Keep this for future features (like "ping", "pause", etc.)
        """
        pass

    async def heartbeat_loop(self):
        """
        Every 15 seconds:
        - update heartbeat
        - deduct minutes
        - kick user if minutes hit zero
        """
        while self.keep_running:
            await asyncio.sleep(15)

            still_active = await self.process_heartbeat(self.viewer_session)

            if not still_active:
                await self.close()
                break

    # ---------------------------
    # DATABASE OPERATIONS (sync → async)
    # ---------------------------

    @sync_to_async
    def get_stream(self, stream_id):
        try:
            return Stream.objects.get(id=stream_id)
        except Stream.DoesNotExist:
            return None

    @sync_to_async
    def get_user_seconds(self, user):
        wallet, _ = MinuteWallet.objects.get_or_create(user=user)
        return wallet.seconds_balance

    @sync_to_async
    def refund_unused_seconds(self, user, seconds_left):
        wallet, _ = MinuteWallet.objects.get_or_create(user=user)
        wallet.refund_from_stream(seconds_left)

        MinuteLedger.objects.create(
            user=user,
            action="refund",
            seconds=seconds_left
        )



    @sync_to_async
    def create_viewer_session(self, user, stream, remaining_minutes, channel_name):
        return StreamViewerSession.objects.create(
            user=user,
            stream=stream,
            remaining_minutes=remaining_minutes,
            websocket_channel_name=channel_name,
            is_active=True,
        )

    @sync_to_async
    def process_heartbeat(self, session: StreamViewerSession):
        """
        Deduct minutes and update heartbeat.
        """
        session.refresh_from_db()

        session.last_heartbeat = now()
        session.remaining_minutes -= 1

        if session.remaining_minutes <= 0:
            session.remaining_minutes = 0
            session.is_active = False
            session.disconnected_at = now()
            session.save()

            # Write back zero balance
            self.sync_return_minutes_to_balance(session.user, 0)
            return False

        session.save()

        # Sync remaining minutes back to user's account
        self.sync_return_minutes_to_balance(
            session.user, session.remaining_minutes
        )

        return True

    @sync_to_async
    def end_viewer_session(self, session: StreamViewerSession):
        session.refresh_from_db()

        session.is_active = False
        session.disconnected_at = now()
        session.save()

        # Return remaining minutes
        self.sync_return_minutes_to_balance(
            session.user, session.remaining_minutes
        )

    @sync_to_async
    def sync_return_minutes_to_balance(self, user, minutes_left):
        balance, _ = UserMinuteBalance.objects.get_or_create(user=user)
        balance.remaining_minutes = minutes_left
        balance.save()
