from django.urls import path
from .views import (
    CreateStreamView,
    StartStreamView,
    JoinStreamView,
    HeartbeatView,
    EndStreamView,
    SendGiftView,
)

urlpatterns = [
    path("create/", CreateStreamView.as_view(), name="create-stream"),
    path("<int:stream_id>/start/", StartStreamView.as_view(), name="start-stream"),
    path("<int:stream_id>/join/", JoinStreamView.as_view(), name="join-stream"),
    path("heartbeat/<int:session_id>/", HeartbeatView.as_view(), name="heartbeat"),
    path("<int:stream_id>/end/", EndStreamView.as_view(), name="end-stream"),
    path("<int:stream_id>/gift/", SendGiftView.as_view(), name="send-gift"),
]
