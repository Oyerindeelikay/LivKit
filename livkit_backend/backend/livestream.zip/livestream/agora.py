from livestream.agora_sdk.rtc_token_builder import RtcTokenBuilder
from django.conf import settings
import time

def issue_agora_token(user, channel, ttl, role):
    expire = int(time.time()) + ttl

    agora_role = (
        RtcTokenBuilder.Role_Publisher
        if role == "publisher"
        else RtcTokenBuilder.Role_Subscriber
    )

    return RtcTokenBuilder.buildTokenWithUid(
        settings.AGORA_APP_ID,
        settings.AGORA_APP_CERTIFICATE,
        channel,
        user.id,
        agora_role,
        expire
    )
