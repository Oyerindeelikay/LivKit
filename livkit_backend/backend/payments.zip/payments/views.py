import json
import stripe
from django.conf import settings
from django.http import HttpResponse
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status

from .models import Entitlement, PaymentLog
from accounts.permissions import IsAuthenticatedAndNotBanned

from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator

from payments.models import MinuteWallet, MinuteLedger

# ---------- STRIPE ---------- #

stripe.api_key = settings.STRIPE_SECRET_KEY


class StripeCreateMinutesCheckoutView(APIView):
    permission_classes = [IsAuthenticated, IsAuthenticatedAndNotBanned]

    def post(self, request):
        user = request.user
        price_id = request.data.get("price_id")

        STRIPE_MINUTE_PRICE_MAP = {
            settings.STRIPE_MINUTES_24H_PRICE_ID: "24_hours",
        }

        if price_id not in STRIPE_MINUTE_PRICE_MAP:
            return Response({"detail": "Invalid minutes package"}, status=400)

        session = stripe.checkout.Session.create(
            mode="payment",
            success_url=settings.FRONTEND_SUCCESS_URL,
            cancel_url=settings.FRONTEND_CANCEL_URL,
            customer_email=user.email,
            line_items=[{"price": price_id, "quantity": 1}],
            metadata={
                "user_id": user.id,
                "type": "watch_minutes",
                "price_id": price_id,
            }
        )

        return Response({"checkout_url": session.url})



class StripeCreateCheckoutView(APIView):
    permission_classes = [IsAuthenticated, IsAuthenticatedAndNotBanned]

    def post(self, request):
        user = request.user
        price_id = request.data.get("price_id")

        if price_id not in STRIPE_COIN_PRICE_MAP:
            return Response({"detail": "Invalid coin package"}, status=400)

        session = stripe.checkout.Session.create(
            mode="payment",
            success_url=settings.FRONTEND_SUCCESS_URL,
            cancel_url=settings.FRONTEND_CANCEL_URL,
            customer_email=user.email,
            line_items=[{"price": price_id, "quantity": 1}],
            metadata={
                "user_id": user.id,
                "type": "gift_coins",
                "price_id": price_id,
            }
        )

        return Response({"checkout_url": session.url})



@csrf_exempt
def stripe_webhook(request):
    payload = request.body
    sig_header = request.META.get("HTTP_STRIPE_SIGNATURE")
    endpoint_secret = settings.STRIPE_WEBHOOK_SECRET

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, endpoint_secret
        )
    except Exception:
        return HttpResponse(status=400)

    event_type = event["type"]
    data_object = event["data"]["object"]
    event_id = event["id"]

    from django.contrib.auth import get_user_model
    from django.db import transaction
    from payments.models import (
        Entitlement,
        MinuteWallet,
        MinuteLedger,
        CoinWallet,
        CoinLedger,
        PaymentLog,
    )

    User = get_user_model()

    # ======================================================
    # CHECKOUT COMPLETED
    # ======================================================
    if event_type == "checkout.session.completed":
        session = data_object
        metadata = session.get("metadata", {})
        payment_intent = session.get("payment_intent")

        user_id = metadata.get("user_id")
        payment_type = metadata.get("type")
        price_id = metadata.get("price_id")

        if not user_id:
            return HttpResponse(status=200)

        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return HttpResponse(status=200)

        # -------------------------------
        # CASE 1: PREMIUM ENTITLEMENT
        # -------------------------------
        if payment_type is None:
            entitlement, _ = Entitlement.objects.get_or_create(user=user)
            if not entitlement.is_active:
                entitlement.activate("stripe", payment_intent)

            PaymentLog.objects.create(
                user=user,
                provider="stripe",
                event=event_type,
                reference=payment_intent,
                payload=session,
            )

        # -------------------------------
        # CASE 2: WATCH MINUTES (SECONDS)
        # -------------------------------
        elif payment_type == "watch_minutes":
            STRIPE_PRICE_TO_SECONDS = {
                settings.STRIPE_MINUTES_24H_PRICE_ID: 86400,  # 24 hours
            }

            seconds = STRIPE_PRICE_TO_SECONDS.get(price_id)
            if not seconds:
                return HttpResponse(status=200)

            # Idempotency (ABSOLUTE MUST)
            if MinuteLedger.objects.filter(stripe_event_id=event_id).exists():
                return HttpResponse(status=200)

            with transaction.atomic():
                wallet, _ = MinuteWallet.objects.get_or_create(user=user)
                wallet.add(seconds)

                MinuteLedger.objects.create(
                    user=user,
                    action="purchase",
                    seconds=seconds,
                    stripe_event_id=event_id,
                    stripe_price_id=price_id,
                )

                PaymentLog.objects.create(
                    user=user,
                    provider="stripe",
                    event=event_type,
                    reference=payment_intent,
                    payload=session,
                )

        # -------------------------------
        # CASE 3: GIFT COINS
        # -------------------------------
        elif payment_type == "gift_coins":
            STRIPE_COIN_PRICE_MAP = {
                settings.STRIPE_COINS_SMALL_PRICE_ID: 100,
                settings.STRIPE_COINS_MEDIUM_PRICE_ID: 500,
                settings.STRIPE_COINS_LARGE_PRICE_ID: 1000,
            }

            coins = STRIPE_COIN_PRICE_MAP.get(price_id)
            if not coins:
                return HttpResponse(status=200)

            if CoinLedger.objects.filter(stripe_event_id=event_id).exists():
                return HttpResponse(status=200)

            with transaction.atomic():
                wallet, _ = CoinWallet.objects.get_or_create(user=user)
                wallet.balance += coins
                wallet.save(update_fields=["balance"])

                CoinLedger.objects.create(
                    user=user,
                    action="purchase",
                    amount=coins,
                    stripe_event_id=event_id,
                )

                PaymentLog.objects.create(
                    user=user,
                    provider="stripe",
                    event=event_type,
                    reference=payment_intent,
                    payload=session,
                )

        return HttpResponse(status=200)

    # ======================================================
    # REFUNDS / DISPUTES
    # ======================================================
    if event_type in ("charge.refunded", "charge.dispute.created"):
        charge = data_object
        refunded_event_id = event_id
        payment_intent = charge.get("payment_intent")

        if not payment_intent:
            return HttpResponse(status=200)

        # Refund ONLY matching purchases
        purchase_ledgers = MinuteLedger.objects.filter(
            action="purchase",
            stripe_event_id__isnull=False,
        )

        for ledger in purchase_ledgers:
            if MinuteLedger.objects.filter(
                action="refund",
                stripe_event_id=refunded_event_id,
            ).exists():
                continue

            wallet = MinuteWallet.objects.get(user=ledger.user)

            with transaction.atomic():
                wallet.seconds_balance = max(
                    0, wallet.seconds_balance - ledger.seconds
                )
                wallet.save(update_fields=["seconds_balance"])

                MinuteLedger.objects.create(
                    user=ledger.user,
                    action="refund",
                    seconds=-ledger.seconds,
                    stripe_event_id=refunded_event_id,
                )

        return HttpResponse(status=200)

    return HttpResponse(status=200)


# ---------- GOOGLE PLAY VERIFY ---------- #

from google.oauth2 import service_account
from googleapiclient.discovery import build


class GoogleVerifyPurchaseView(APIView):
    permission_classes = [IsAuthenticated, IsAuthenticatedAndNotBanned]

    def post(self, request):
        user = request.user

        entitlement, _ = Entitlement.objects.get_or_create(user=user)
        if entitlement.is_active:
            return Response({
                "already_paid": True,
                "message": "You’ve already unlocked premium content!"
            }, status=200)



        purchase_token = request.data.get("purchaseToken")
        product_id = request.data.get("productId")
        package_name = request.data.get("packageName")

        if not (purchase_token and product_id and package_name):
            return Response({"error": "Missing fields"}, status=400)

        credentials = service_account.Credentials.from_service_account_file(
            settings.GOOGLE_SERVICE_ACCOUNT_FILE,
            scopes=["https://www.googleapis.com/auth/androidpublisher"],
        )

        service = build("androidpublisher", "v3", credentials=credentials)
        result = service.purchases().products().get(
            packageName=package_name,
            productId=product_id,
            token=purchase_token
        ).execute()

        # Google's response
        purchase_state = result.get("purchaseState")   # 0 = Purchased
        order_id = result.get("orderId")

        if purchase_state != 0:
            return Response({"error": "Purchase not valid"}, status=400)

        entitlement.activate("playstore", order_id)

        PaymentLog.objects.create(
            user=user,
            provider="playstore",
            event="purchase.verified",
            reference=order_id,
            payload=result
        )

        return Response({"detail": "Access granted"})
